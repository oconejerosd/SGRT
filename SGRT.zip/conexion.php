<?php
    $host = 'localhost';
    $user = 'root';
    $password = '';
    $db = 'bd_sgrt';

    $conection = @mysqli_connect($host,$user,$password,$db);

    if(!$conection){
        echo "Error en la conexion";
    }

?>