<footer style="background-color: #8d5ba1;">
  <!-- Copyright -->
  <div class="text-center p-3 text-light">
    © 2021 Copyright - 
    <a class="text-light">Departamento de Informática - Corporación Municipal de Rancagua</a>
  </div>
  <!-- Copyright -->
</footer>